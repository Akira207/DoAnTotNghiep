import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ["admin", "worker", "accountant"],
    default: "worker",
  },
  phone: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
  name: {
    type: String,
  },
  address: {
    type: String,
  },
  email: {
    type: String,
  },
});

export default mongoose.model("User", userSchema);
